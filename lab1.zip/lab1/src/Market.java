import java.io.BufferedReader;
import java.io.IOException;
import java.util.Formatter;

public class Market {
    private String name;
    private String description;
    private int price;
    private int unit_available;
    private int unit_measurement;
    private int ID;

    public Market() {
        name = "None";
        description= "None";
        price = 0;
        unit_available = 0;
        unit_measurement = 0;
        ID = 0;
    }

    public Market(Market other) {
        name = other.name;
        description = other.description;
        price = other.price;
        unit_available = other.unit_available;
        unit_measurement = other.unit_measurement;
        ID = other.ID;
    }

    public Market clone() {
        return new Market(this);
    }

    public boolean equal(Student other) {
        return (name.equals(other.name) &&
                surname.equals(other.surname) &&
                faculty.equals(other.faculty) &&
                birth == other.birth &&
                entering == other.entering &&
                ID == other.ID);
    }

    public void readingFile(BufferedReader reader) throws IOException {
        String line = reader.readLine();
        String[] fields = line.split(",");

        name = fields[0];
        description = fields[1];
        price = Integer.parseInt(fields[2]);
        unit_available = Integer.parseInt(fields[3]);
        unit_measurement = Integer.parseInt(fields[4]);
        ID = Integer.parseInt(fields[5]);
    }

    public void writeElement() {
        System.out.println(name + ", " +
                           description + ", " +
                           price + ", " +
                           unit_available + ", " +
                           unit_measurement + ", " +
                           ID);
    }

    public void writeTable(Formatter formatter) {
        formatter.format("%-15s %-15s %-15s %-10d %-10d %-4d\n", name, description, price, unit_available, unit_measurement, ID);
    }
}
